<?php
/*
  App-specific configuration for your game.

  You will need to configure:
    - the URL to the server where you are hosting the game source code.
    - create a new App and retrieve the app ID and namespace from Facebook
    Developer site at https://developers.facebook.com/apps
*/
  $serverUrl = "https://www.curioerp.com/gameslyce/plugins/fbpro";
  $appNamespace = "gametestfeatures";
  $appId = "864246060388493";
?>
